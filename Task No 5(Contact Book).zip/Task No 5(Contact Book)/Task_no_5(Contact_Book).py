from tkinter import *  
from tkinter import messagebox 
from tkinter import ttk 
import pyodbc 
import re  
from tkinter import simpledialog 


class ContactBook(Tk):
    def __init__(self): 
        super().__init__() 
        self.title("Contact Book") 
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()

        self.geometry(f"{screen_width}x{screen_height}")

    # --> Connect to data base Function 👇👇👇
    def ConnectToDataBase(self):
        
        # --> String Of connection 👇👇👇
        conn_str = 'Driver={SQL Server};Server=DESKTOP-FPO2BUS\SQLEXPRESS;Database=ContactBook;Trust_Connection = yes;'
        
        try:
            conn = pyodbc.connect(conn_str)
        except:
            messagebox.showerror("Error","Error in Connecting to Data Base")
        finally:
            cursor = conn.cursor()
            return cursor
        
        # --> Back to home page function by clicking button 👇👇👇
    def BackToPage(self,data):
                data.destroy()
                HomePage = ContactBook()
                HomePage.HomePage()

    # --> Home page of form  Start Here --> 👇👇👇 
    def HomePage(self):
        def on_combobox_selected(event): 
            return cmbUser.get()
            
        Label(self,text="Contact Book ",font="Algerian 15 bold",bg="Blue",relief=SUNKEN,pady=8,padx=50).grid(row=0,column=3,pady=20)
        Label(self,text="Home Page",font="Algerian 15 bold",bg="Blue",relief=SUNKEN,pady=8,padx=25).grid(row=1,column=3,pady=25)
        Label(self,text="Enter the user choice",font="calibri 14",padx=10).grid(row=8,column=1,pady=22)
        
        user = ["New Contact","Check The Contact List"] # --> Making list thet value show in combo box

        cmbUser = ttk.Combobox(self,values=user,width=20) # --> Making Combo box 
        cmbUser.current(0)
        cmbUser.grid(row=8,column=2,padx=12)
        # --> Bind is a function which use to create special event of tkinter application
        cmbUser.bind("<<ComboboxSelected>>", on_combobox_selected) # --> Create event to get value from combo box 
        
        def Choice(): # --> Get Choice for combo box in home page
            if(user[0] == on_combobox_selected(event=cmbUser)): # --> value = new user
                self.FormPage()  # --> Open Admission form page
            elif(user[1] == on_combobox_selected(event=cmbUser)): # --> value = manager 
                self.SearchDataInDB() # --> Open Admin Page
            else:
                messagebox.showerror("Error","Plz Choice Correct User Types")    
        # --> Here Command --> Choice on home page
        Button(self,text="Next ",font="calibri 14 bold",command=Choice,width=12,bg="Red").grid(row=10,column=2,pady=20)
        Button(self,text="Exit ",font="calibri 14 bold",command=self.destroy,width=12,bg="Red").grid(row=10,column=3,pady=20)
        
    # --> Home page of form End Here --> 👆👆👆
    
        # --> Search page of form  Start Here --> 👇👇👇 
    def SearchDataInDB(self):
            self.destroy() # --> Admin Page Close
            SearchData = ContactBook() # --> Search Page Open

            Label(SearchData,text="Contact Book",font="Algerian 15 bold",bg="Blue",relief=SUNKEN,pady=8).grid(row=0,column=6,pady=20)
            Label(SearchData,text="Operations page",font="Algerian 15 bold",bg="Blue",relief=SUNKEN,pady=8).grid(row=1,column=6,pady=25)

             # --> Data Display page of form  Start Here --> 👇👇👇 
            
            def SearchAContact():
                        update_id = simpledialog.askstring("Search Contact", "Enter the name of the contact to search:")
    
                        if not update_id:
                                return
                        cursor = SearchData.ConnectToDataBase()
    
                        try:
                            cursor.execute("SELECT * FROM ContactStore WHERE Name=?", (update_id,))
                            contact_data = cursor.fetchone()

                            if contact_data:
                                    SearchData.destroy()
                                    search_window = ContactBook()
                                    search_window.title("Search Contact")

                                    name_label = Label(search_window, text="Name:")
                                    name_label.grid(row=3,column=6,padx=100,pady=10)
                                    name_entry = Entry(search_window)
                                    name_entry.insert(0, contact_data[1])
                                    name_entry.grid(row=4,column=6,padx=100,pady=10)

                                    phone_label = Label(search_window, text="Phone No:")
                                    phone_entry = Entry(search_window)
                                    phone_entry.insert(0, contact_data[2])
                                    phone_label.grid(row=5,column=6,padx=100,pady=10)
                                    phone_entry.grid(row=6,column=6,padx=100,pady=10)

                                    email_label = Label(search_window, text="Email:")
                                    email_entry = Entry(search_window,width=30)
                                    email_entry.insert(0, contact_data[3])
                                    email_label.grid(row=7,column=6,padx=100,pady=10)
                                    email_entry.grid(row=8,column=6,padx=100,pady=10)

                                    address_label = Label(search_window, text="Address:")
                                    address_entry = Entry(search_window,width=50)
                                    address_entry.insert(0, contact_data[4])
                                    address_label.grid(row=9,column=6,padx=100,pady=10)
                                    address_entry.grid(row=10,column=6,padx=100,pady=10)
                                    Button(search_window,text="Back to home page",command=lambda:self.BackToPage(search_window),width=20,bg="Red",font="calibri 14 bold").grid(row=12,column=6)

                            else:
                                        messagebox.showerror("Error", "Contact not found")
                        except Exception as e:
                                    print(str(e))
                                    cursor.rollback()
                        finally:
                                    cursor.close() 
  
            def Find(): 
                SearchData.destroy() # --> Search Page Close
                data = ContactBook() # --> Data Display Page Open

                cursor = data.ConnectToDataBase() # --> Return the connection 
                search_sql = """ 
                    SELECT * FROM ContactStore
                    """   # --> Sql Command For Show all record
                # -->Here Execption Handling to handle the error        
                try:
                    cursor.execute(search_sql) # --> Here Show Command Execute
                    bar = Scrollbar(data,orient=VERTICAL)
                    bar.grid(row=3,column=5)
                    # --> Make The Column Heading 👇👇👇
                    cols = ("ID","Name","PhoneNo","Email","Address")
                    tree = ttk.Treeview(data,yscrollcommand=bar.set,show="headings",columns=cols) # --> Make a Table on GUI Page
                    bar.config(command=tree.yview)
                    style = ttk.Style(data) # --> Style the Heading
                    style.theme_use("clam") # --> Set THe Theme
                    

                    data.geometry("1000x500") # --> Set The Width and Height
                    tree.column("ID",width=30,anchor=CENTER) # --> Make the column 
                    tree.column("Name",width=70,anchor=CENTER) # --> Make the column
                    tree.column("PhoneNo",width=100,anchor=CENTER) # --> Make the column
                    tree.column("Email",width=180,anchor=CENTER) # --> Make the column
                    tree.column("Address",width=300,anchor=CENTER) # --> Make the column

                    tree.heading("ID",text="ID",anchor=CENTER) # --> Make the heading text
                    tree.heading("Name",text="Name",anchor=CENTER) # --> Make the heading text
                    tree.heading("PhoneNo",text="PhoneNo",anchor=CENTER)# --> Make the heading text
                    tree.heading("Email",text="Email",anchor=CENTER) # --> Make the heading text
                    tree.heading("Address",text="Address",anchor=CENTER) # --> Make the heading heading text

                    for row in cursor: # --> Data Insert into the table for show the data
                        tree.insert("","end",values=(row[0],row[1],row[2],row[3],row[4]))
                    tree.grid(row=3,column=4) # --> adjust the tree on GUI Pag

                    def DeleteAContact():
                            delete = tree.selection()
                            if delete:
                                 item_name = tree.item(delete[0])['values'][1]
                                 cursor = data.ConnectToDataBase()
                            try:
                                    cursor.execute("DELETE FROM ContactStore WHERE name=?",(item_name,))
                                    cursor.commit()
                                    tree.delete(delete)
                                    messagebox.Message("Data","Data Deleted From Data Base")
                             
                            except IndexError:
                                messagebox.showerror("Error","Plz Select the contact from the box") 
                            
                            finally:
                                 cursor.close()
                    Button(data,text="Back to Home Page",command=lambda:self.BackToPage(data),width=20,bg="Red",font="calibri 14 bold").grid(row=5,column=4,padx=10,pady=25)
                    Button(data,text="Delete",command=DeleteAContact,width=15,bg="Red",font="calibri 14 bold").grid(row=6,column=4,padx=10,pady=25)
                except EXCEPTION as e:
                    print(e.value)
                    messagebox.showwarning("Message","Error in Searching") 
        

                 # --> Data Display page of form  End Here --> 👆👆👆
                
                # --> Here Command --> Find which Show the member of ContactBook (home --> Admin --> Search --> Data Display)
            Button(SearchData,text="Show Full Contact Book",command=Find,width=24,bg="Red",font="calibri 14 bold").grid(row=5,column=4,padx=35,pady=25)
            Button(SearchData,text="Search A Contact",command=SearchAContact,width=20,bg="Red",font="calibri 14 bold").grid(row=5,column=5,padx=35,pady=25)
            Button(SearchData,text="Back to home page",command=lambda:self.BackToPage(SearchData),width=20,bg="Red",font="calibri 14 bold").grid(row=5,column=6)
            # --> Search page of form  End Here --> 👆👆👆 
        
    # --> Adminssion form page of form Start Here --> 👇👇👇
    def FormPage(self):  
        self.destroy() # --> Home page Close
       
        # Start --> All Function Defination which use to in form 
        def SaveData(): # ==> 1
            Data = self.ConnectToDataBase() #--> Connection return
            Name = nameVar.get() # --> Get the Value from entry widget
            PhoneNo = phoneNo.get() # --> Get the Value from entry widget
            Email = email.get() # --> Get the Value from entry widget
            Address = AddressEntry.get() # --> Get the Value from entry widget# --> Get the Value from List Box Function
            insertData = """
            INSERT INTO ContactStore
            VALUES (?,?,?,?)
            """   # --> SQL data inser Statment
        
            # -->Here Execption Handling to handle the error
            try:
                Data.execute(insertData,Name,PhoneNo,Email,Address)
            except :
                Data.rollback()
                messagebox.showerror("Error","Error for inserting data")
            else:
                Data.commit()
                messagebox.showinfo("Message","Data are inserted into DB")          
                Data.close()   #--> Close the function      

            SubmitForm() # --> Calling the submit form function 
        def EmailCheck(): # ==> 2 # --> Check the Email 
            if validate_email_format(email.get()): # --> Check Email Validate or Not 
                SaveData() # --> Save the data in data base
            else:
                messagebox.showerror("Message Box", "Invalid e mail format")# --> Show the message box when email is not valid
        def validate_email_format(email): # ==> 3 # --> Pattern of Email Check
            pattern = r"^\w+([\.-]?\w+)*@gmail\.com$" # --> This is Correct Format of Email 
            if re.match(pattern, email): # --> Check your email with the Correct Pattern 
                return True
            else:
                return False 
        
        def SubmitForm(): # ==> 6 # --> Clear AnyThing When we enter the submit button 
            messagebox.showinfo("Message","Your Contact save in the ContactBook")
            nameEntry.delete(0,END)
            phoneNoEntry.delete(0,END)
            phoneNoEntry.insert(0,"+92")
            emailEntry.delete(0,END)
            emailEntry.insert(0,"@gmail.com")
            AddressEntry.delete(0,END)

        def move_to_next(event): # ==> 7 # --> We Click the "Enter" button to move next Entry in the form 
            event.widget.tk_focusNext().focus()

        formPage = ContactBook() #--> Open the form page

        # --> 👇👇👇 Label 
        Label(formPage,text="Contact Book",font="Algerian 15 bold",bg="Blue",relief=SUNKEN,pady=12,padx=50).grid(row=0,column=4,pady=12)
        

        # --> 👇👇👇 All Labels of Form and Grid is used to show data on the form 
        Label(formPage,text="Name",font="calibri 14",padx=10).grid(row=1,column=3,pady=5)
        Label(formPage,text="Phone No",font="calibri 14",padx=10).grid(row=2,column=3)
        Label(formPage,text="Email",font="calibri 14",padx=10).grid(row=3,column=3)
        Label(formPage,text="Address",font="calibri 14",padx=10).grid(row=4,column=3)


        # --> 👇👇👇 Making the Varaible of All Label4
        nameVar = StringVar()
        phoneNo = StringVar()
        email = StringVar()
        Address = StringVar()

        # --> 👇👇👇 Making the Entry of All Labels and Grid is used to show data on the form 
        nameEntry = Entry(formPage,textvariable=nameVar,width=25)
        nameEntry.grid(row=1,column=4)
        nameEntry.bind("<Return>",move_to_next) # --> Create event to move one entry to other entry by clicking "enter" button
        nameEntry.focus_set()

        
        phoneNoEntry = Entry(formPage,textvariable=phoneNo,width=25)
        phoneNoEntry.grid(row=2,column=4)
        phoneNoEntry.insert(0,"+92")
        phoneNoEntry.bind("<Return>", move_to_next)  # --> Create event to move one entry to other entry by clicking "enter" button

        emailEntry = Entry(formPage,textvariable=email,width=25)
        emailEntry.insert(0, "@gmail.com")
        emailEntry.grid(row=3,column=4)
        emailEntry.bind("<Return>", move_to_next)  # --> Create event to move one entry to other entry by clicking "enter" button

        AddressEntry = Entry(formPage,textvariable=Address,width=50,)
        AddressEntry.grid(row=4,column=4)
        AddressEntry.bind("<Return>", move_to_next)  # --> Create event to move one entry to other entry by clicking "enter" button

        # --> 👇👇👇 Making Button to Submit the data 

        # --> Here Command --> Check the Email amd Checking other command on the Form Page 
        submitBtn = Button(formPage,text="Submit Record",command=EmailCheck,width=12,bg="Red",font="calibri 14 bold")
        submitBtn.grid(row=10,column=4,pady=15)
        Button(formPage,text="Back To Home Page",command=lambda:self.BackToPage(formPage),width=20,bg="Red",font="calibri 14 bold").grid(row=10,column=6)


form = ContactBook() # --> Make the object
form.HomePage() # --> calling the Home Page

form.mainloop()