CREATE DATABASE ContactBook;

CREATE TABLE ContactStore
( ID INT IDENTITY(1,1) PRIMARY KEY,
  Name VARCHAR(255) NOT NULL,
  PhoneNo VARCHAR(255) NOT NULL,
  Email VARCHAR(255) NOT NULL,
  AddressHouse VARCHAR(255)
)

INSERT INTO ContactStore(Name,PhoneNo,Email,AddressHouse)
VALUES('Ahmed','+92 322 1234567','ahmed23@gmail.com','House no 3,Street no 2 Abdullah Pur Faisalabad'),
('Amna','+92 321 9087654','amnanoor23@gmail.com','House no 2,Street no 3 208 chak Faisalabad'),
('Awais','+92 322 6096266 ','awais243@gmail.com','House no 1,Street no 2 Abdullah Pur Faisalabad'),
('Faran','+92 305 2345670','faran675@gmail.com','House no 17,Street no 1 People Colony Faisalabad'),
('Eman','+92 322 7654321','eman423@gmail.com','House no 1,Street no 1 Abdullah Pur Faisalabad')

SELECT * FROM ContactStore;

